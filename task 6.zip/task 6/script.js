document.getElementById('userForm').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent form submission
  
    let isValid = true;
  
    // Validate Username
    const username = document.getElementById('username');
    const usernameError = document.getElementById('usernameError');
    if (username.value.trim() === '') {
      usernameError.textContent = 'Username is required.';
      usernameError.style.display = 'block';
      isValid = false;
    } else {
      usernameError.style.display = 'none';
    }
  
    // Validate Email
    const email = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.value.trim())) {
      emailError.textContent = 'Enter a valid email address.';
      emailError.style.display = 'block';
      isValid = false;
    } else {
      emailError.style.display = 'none';
    }
  
    // Validate Password
    const password = document.getElementById('password');
    const passwordError = document.getElementById('passwordError');
    if (password.value.trim().length < 6) {
      passwordError.textContent = 'Password must be at least 6 characters.';
      passwordError.style.display = 'block';
      isValid = false;
    } else {
      passwordError.style.display = 'none';
    }
  
    // If all fields are valid, submit the form
    if (isValid) {
      alert('Form submitted successfully!');
      this.submit();
    }
  });