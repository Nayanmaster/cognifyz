// Fetch data from the JSONPlaceholder API
fetch('https://jsonplaceholder.typicode.com/posts')
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok ' + response.statusText);
    }
    return response.json(); // Parse the JSON data
  })
  .then(data => {
    // Dynamically update the DOM with the fetched data
    const container = document.getElementById('data-container'); // Ensure this element exists in your HTML

    data.slice(0, 5).forEach(post => { // Display only the first 5 posts
      const postElement = document.createElement('div');
      postElement.classList.add('post');
      postElement.innerHTML = `
        <h3>${post.title}</h3>
        <p>${post.body}</p>
      `;
      container.appendChild(postElement);
    });
  })
  .catch(error => {
    console.error('There was a problem with the fetch operation:', error);
  });